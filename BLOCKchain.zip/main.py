from PublicLedger import Publicledger
from Miner import miner
from user import user
import os


"""""""""""""""""""""""""""""""""""""""""ZH CRYPTO"""""""""""""""""""""""""""""""""""""""

PL=Publicledger.create(Publicledger)            #protected by singleton pattern

print("\t\t\t\t\tWELCOME TO ZH CRYPTO\t\t\t")
mminer=miner(PL.getFileName())
user1=user("Zohaib","zohaib007",PL,mminer)
user2=user("hammad","lololol",PL,mminer)
user3=user("Sunil","kothari",PL,mminer)
user4=user("haider","sheikh",PL,mminer)

print("USER 1")
user1.maketransaction()
os.system("clear")
print("USER 2")
user2.maketransaction()




